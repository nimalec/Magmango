##test_incar.py 
from magmango.calculation.incar import IncarSettings as Incar 
def test_incar_1(file_path):  
   incar = Incar(file_path)
   return incar   

if __name__ == main: 
   file_path = "INCAR" 
   incar = test_incar_1(file_path)  

