##test_mae.py  
import os 
from numpy import pi 
from magmango.mae.mae_calc import MagneticAnisotropyFlow as MAEFlow 
from magmango.calculation.incar import IncarSettings  as Incar 
from magmango.calculation.kpoints import KPointsSettings as KPoints 
from magmango.calculation.poscar import PoscarSettings as Poscar 
from magmango.calculation.potcar import PotcarSettings as Potcar 
from magmango.calculation.runscript import RunscriptSettings as Runscript  
def test_mae(work_dir, npoints, angle_range, incar, poscar, potcar, kpoints, run_script):
   mae = MAEFlow( ) 
   mae.set_ncl_calculations() 
   mae.make_calculations() 


if __name__ == main:  
   work_dir = os.getcwd() 
   npoints = 20 
   angle_range = [[0, pi/4], [0,pi/4]]  
   incar = Incar()
   kpoints = KPoints() 
   poscar = Poscar() 
   potcar = Potcar() 
   run_script = Runscript() 

   incar.incar_from_file("INCAR")  
   kpoints.kpoints_from_file("KPOINTS") 
   poscar.poscar_from_file("POSCAR") 
   kpoints.potcar_from_file("POTCAR") 
   runscript.runscript_from_file("runscript.sh")
   test_mae(work_dir, npoints, angle_range, incar, poscar, potcar, kpoints, runscript)  
  
  
  
     
