import unittest
import os

import numpy as np
from magmango.calculation.incar import IncarSettings


## Incar test cases:
##  - incar settings (for start, electronic, etc.)
##  - from_file method
##  - get_settings method
##  - update_settings method
##  -write_file method

class IncarSettingsTest(unittest.TestCase):
   def setUp(self):
      self.incar_in_file = os.path("data/incar_pto")
      settings = {}
      settings["start"] = {}
      settings["electronic"] = {}
      settings["parallel"] = {}
      settings["ionic"] = {}
      settings["hubbard"] = {}
      settings["hybrid"] = {}
      settings["misc"] = {}

   def test_default_settings(self):
      start = {"nwrite": 2, "istart": 1, "iniwav": 1, "icharg": None, "nelect": None, "loptics": ".FALSE.","isym": -1 , "lel": None, "lvhar": None, "rwigs": None, "lvtof": None, "nbands": None, "lwave": None}
      electronic =  {"prec":"Accurate" , "algo": "Normal", "encut": 800,
      "nelm": None, "nelmin": None, "gga": "PS" ,"ediff": 10E-05, "ismear": 1, "sigma": 0.2, "lasph": ".TRUE.", "lreal": "Auto", "addgrid": ".TRUE.", "maxmix": 100, "bmix": 1.5}
      parallel = {"ncore": "2" , "lplane": ".TRUE.",  "kpar": "2"}

      incar_sett = IncarSettings()
      for key in start:
          self.assertEqual(incar_sett["start"][key], start[key])
      #for key in electronic:
     #     self.assertEqual((incar_sett["electronic"][key], electronic[key])
      #for key in parallel:
     #     self.assertEqual((incar_sett["parallel"][key], parallel[key]))

   # def test_from_file(self):
   #     incar_sett = IncarSettings()
   #     incar_sett.incar_from_file(self.incar_in_file)
   #     for key_1 in self.settings:
   #         for key_2 in self.settings[key_1]:
   #             self.assertEqual(incar_sett[key_1][key_2], self.settings[key_1][key_2])
