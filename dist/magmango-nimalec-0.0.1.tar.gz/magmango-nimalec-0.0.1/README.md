# Magmango
![alt text](https://github.com/nimalec/Magmango/blob/master/image/magmango_diagram.png))

Magmango is an open source package for first-principles magnetic property predictions of dilute and bulk magnetic materials. 

