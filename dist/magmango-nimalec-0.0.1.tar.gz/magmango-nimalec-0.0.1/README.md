# Magmango
Magmango is an open source package for first-principles magnetic property predictions of dilute and bulk magnetic materials. 

