import numpy as np
import os
from shutil import copyfile
from structure import *
from in_out import * 
