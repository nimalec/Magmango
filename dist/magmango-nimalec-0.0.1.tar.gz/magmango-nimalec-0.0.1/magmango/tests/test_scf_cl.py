##test_scf_cl.py 
def test_scf_cl() 
